<?php
session_start();
if(!isset($_SESSION['email'])) {
  header("Location: login.php");
}
// include "php/connect.php";
?>


<html>
<head>
  <title> News </title>
  <link rel="stylesheet" type="text/css" href="cssnya.css">
  <script src="ckeditor/ckeditor.js"></script>
</head>

<body>

  <div class="container1">

    <?php require_once 'nav.php' ?>

    <div class="akun" style="position: relative; width: 100%; top: 30px; height: 100px">

      <a href="akun_baca.php" class="menu_akun">Saya membaca</a>
      <a href="akun_setting.php" class="menu_akun">Setting akun</a>
      <?php
      if($_SESSION['status'] == "editor") {
        echo '<a href="tambah_berita.php" class="menu_akun">Post berita</a>
        <a href="pilih_berita.php" class="menu_akun aktif">Pilih berita</a>';
      }
      ?>

      <div class="clear">

      <div class="content_akun">
        <form action="php/set_pilihan.php" action="get">
          <div class="box" style="position: relative; left: 0%; top: 0px;">


<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "berita");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT * FROM tb_berita";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table border=1>";
            echo "<tr>";
                echo "<th>id</th>";
                echo "<th>judul</th>";
                echo "<th>penulis</th>";
                echo "<th>kategori</th>";
                echo "<th>isi</th>";
                echo "<th>opsi</th>";


            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['judul'] . "</td>";
                echo "<td>" . $row['penulis'] . "</td>";
                echo "<td>" . $row['kategori'] . "</td>";
                echo "<td>" . $row['isi'] . "</td>"; 
                echo "<td><a href='edit.php?id=$row[id]'>Edit</a> | <a href='delete.php?id=$row[id]'>Delete</a></td></tr>";

            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>





<!--             <label>BERITA PILIHAN</label><br />
              <table border="1" class="table">
    <tr>
      <th>id</th>
      <th>judul</th>
      <th>penulis</th>
      <th>kategori</th>
      <th>Opsi</th>   
    </tr>
    <?php 
    // include "php/connect.php";
    $query_mysqli = mysqli_query("SELECT * FROM tb_berita")or die(mysqli_error());
    $nomor = 1;
    while($data = mysqli_fetch_array($query_mysqli)){
    ?>
    <tr>
      <td><?php echo $id++; ?></td>
      <td><?php echo $data['judul']; ?></td>
      <td><?php echo $data['penulis']; ?></td>
      <td><?php echo $data['kategori']; ?></td>
      <td><?php echo $data['isi']; ?></td>
      <td>
        <a class="edit" href="edit.php?id=<?php echo $data['id']; ?>">Edit</a> |
        <a class="hapus" href="hapus.php?id=<?php echo $data['id']; ?>">Hapus</a>         
      </td>
    </tr>
    <?php } ?>
  </table> -->
          </div>
          </div>
        </form>
      </div>

  </div>


  </div>



  <?php require_once 'foot.php' ?>

</body>
</html>
