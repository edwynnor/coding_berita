<div style="background-color: white; height: 60px; width: 86%; box-shadow: 4px 4px 4px rgba(0,0,0,.5); margin: 0 auto"></div>

<div class="footer">
  Hak Cipta <br>
  
  Edwyn Nor Hidayanto (1714321011)<br>
  <br>
  Mata Kuliah<br>
  Cloud Computing<br>
  
</div>
