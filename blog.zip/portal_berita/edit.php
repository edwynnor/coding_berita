<?php
session_start();
if(!isset($_SESSION['email'])) {
  header("Location: login.php");
}


// include "php/connect.php";
?>


<html>
<head>
  <title> News </title>
  <link rel="stylesheet" type="text/css" href="cssnya.css">
  <script src="ckeditor/ckeditor.js"></script>
</head>

<body>

  <div class="container1">

    <?php require_once 'nav.php' ?>

    <div class="akun" style="position: relative; width: 100%; top: 30px; height: 100px">

      <a href="akun_baca.php" class="menu_akun">Saya membaca</a>
      <a href="akun_setting.php" class="menu_akun">Setting akun</a>
      <?php
      if($_SESSION['status'] == "editor") {
        echo '<a href="tambah_berita.php" class="menu_akun">Post berita</a>
        <a href="pilih_berita.php" class="menu_akun aktif">Pilih berita</a>';
      }
      ?>

      <div class="clear">

      <div class="content_akun">
        <form action="php/set_pilihan.php" action="get">
          <div class="box" style="position: relative; left: 0%; top: 20px;">
          	<form name="update_user" method="post" action="edit.php">
        <table border="0">
<!--         	<?php
                        $link = mysqli_connect("localhost", "root", "", "berita");
 
            // Check connection
            if($link === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
            }
 
            // Attempt select query execution
            $sql = "SELECT * FROM tb_berita";
            if(isset($_GET['id'])){
              while ($row = mysqli_fetch_array()) {
                # code...
                $judul = $row['judul'];
                $penulis = $row['penulis'];
                $kategori = $row['kategori'];
              }
            }
	         
           ?> -->
            <tr> 
                <td>judul</td>
                <td><input type="text" name="judul" value=<?php echo $judul;?>></td>
            </tr>
            <tr> 
                <td>penulis</td>
                <td><input type="text" name="penulis" value=<?php echo $penulis;?>></td>
            </tr>
            <tr> 
                <td>kategori</td>
                <td><input type="text" name="kategori" value=<?php echo $kategori;?>></td>
            </tr>
            <tr> 
                <td>isi</td>
                <td><input type="text" name="isi" value=<?php echo $isi;?>></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="submit" name="update" value="update"></td>
            </tr>
        </table>
    </form>

   </div>
          </div>
        </form>
      </div>

  </div>


  </div>



  <?php require_once 'foot.php' ?>

</body>
</html>

